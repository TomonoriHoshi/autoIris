#!/usr/bin/bash
Rscript autoIris.R
